-- My Event App: database setup for Supabase.
-- Run once: Supabase dashboard > SQL Editor > New query > paste this whole file > Run.
-- Safe to run again: it only creates what is missing and refreshes policies and functions.

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  username text unique check (username ~ '^[a-z0-9_]{3,20}$'),
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id text primary key check (id ~ '^[a-z0-9]{6,12}$'),
  owner uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('birthday','wedding','graduation','baby','other')),
  name text not null,
  headline text not null default '',
  ribbon text not null default '',
  event_date date not null,
  event_time text not null default '',
  venue text not null default '',
  goal integer not null default 0 check (goal >= 0),
  age integer not null default 0 check (age >= 0 and age <= 150),
  msg text not null default '',
  photo text not null default '',
  frame text not null default 'pink' check (frame in ('pink','purple','gold','sky')),
  access text not null default 'invite' check (access in ('invite','link')),
  open_guests boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists events_owner_idx on public.events(owner);

-- Ticketed events: guests pay the host's ticket price and everyone who has paid is welcome.
-- Existing events stay gift events.
alter table public.events add column if not exists kind text not null default 'gift' check (kind in ('gift','ticket'));
alter table public.events add column if not exists ticket_price numeric(10,2) not null default 0 check (ticket_price >= 0 and ticket_price <= 1000000);
alter table public.events add column if not exists ticket_total integer not null default 0 check (ticket_total >= 0 and ticket_total <= 100000);
do $$
begin
  alter table public.events add constraint events_ticket_chk
    check (kind = 'gift' or (ticket_price > 0 and ticket_total > 0));
exception when duplicate_object then null;
end $$;

create table if not exists public.guests (
  event_id text not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  via text not null default 'host',
  status text not null default 'pending' check (status in ('pending','going','maybe','no')),
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);
create index if not exists guests_user_idx on public.guests(user_id);

create table if not exists public.requests (
  event_id text not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  via text not null,
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);
create index if not exists requests_user_idx on public.requests(user_id);

create table if not exists public.gifts (
  id uuid primary key default gen_random_uuid(),
  event_id text not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_id text not null,
  emoji text not null,
  label text not null,
  price numeric(10,2) not null check (price >= 0 and price <= 1000),
  created_at timestamptz not null default now()
);
create index if not exists gifts_event_idx on public.gifts(event_id);
create index if not exists gifts_user_idx on public.gifts(user_id);

create table if not exists public.friends (
  owner_id uuid not null references public.profiles(id) on delete cascade,
  friend_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (owner_id, friend_id),
  check (owner_id <> friend_id)
);

-- One row per ticket. Rows are created only by buy_ticket() and changed only by cancel_ticket().
create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  event_id text not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  code text not null unique,
  price numeric(10,2) not null check (price > 0),
  status text not null default 'valid' check (status in ('valid','cancelled')),
  pay_ref text not null default 'placeholder',
  created_at timestamptz not null default now()
);
create index if not exists tickets_event_idx on public.tickets(event_id);
create index if not exists tickets_user_idx on public.tickets(user_id);

-- ---------------------------------------------------------------------------
-- A profile row is created automatically for every new account
-- ---------------------------------------------------------------------------

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name)
  values (
    new.id,
    coalesce(
      nullif(new.raw_user_meta_data->>'full_name', ''),
      nullif(new.raw_user_meta_data->>'name', ''),
      split_part(coalesce(new.email, ''), '@', 1)
    )
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

insert into public.profiles (id, name)
select id, split_part(coalesce(email, ''), '@', 1) from auth.users
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- Helper functions. They run with owner rights so policies can look across
-- tables without looping back into row-level security.
-- ---------------------------------------------------------------------------

create or replace function public.is_owner(eid text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.events e where e.id = eid and e.owner = auth.uid());
$$;

create or replace function public.is_guest(eid text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.guests g where g.event_id = eid and g.user_id = auth.uid());
$$;

create or replace function public.is_link_event(eid text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.events e where e.id = eid and e.access = 'link');
$$;

create or replace function public.allows_guest_invites(eid text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.events e where e.id = eid and e.open_guests);
$$;

create or replace function public.is_ticket_event(eid text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.events e where e.id = eid and e.kind = 'ticket');
$$;

create or replace function public.can_view_event(eid text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.events e
    where e.id = eid
      and (e.owner = auth.uid()
           or e.access = 'link'
           or exists (select 1 from public.guests g where g.event_id = e.id and g.user_id = auth.uid()))
  );
$$;

-- ---------------------------------------------------------------------------
-- Row-level security: who can read and write what
-- ---------------------------------------------------------------------------

alter table public.profiles enable row level security;
alter table public.events enable row level security;
alter table public.guests enable row level security;
alter table public.requests enable row level security;
alter table public.gifts enable row level security;
alter table public.friends enable row level security;
alter table public.tickets enable row level security;

-- profiles: signed-in people can read names and usernames; you edit only your own
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (true);
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- events: the host and invited guests can read the table.
-- Anyone with the code of an "anyone with the code" event reads it through get_event().
drop policy if exists events_read on public.events;
create policy events_read on public.events for select to authenticated
  using (owner = auth.uid() or public.is_guest(id));
drop policy if exists events_insert on public.events;
create policy events_insert on public.events for insert to authenticated
  with check (owner = auth.uid());
drop policy if exists events_update on public.events;
create policy events_update on public.events for update to authenticated
  using (owner = auth.uid()) with check (owner = auth.uid());
drop policy if exists events_delete on public.events;
create policy events_delete on public.events for delete to authenticated
  using (owner = auth.uid());

-- guests: the host sees everyone; each guest sees only their own row
drop policy if exists guests_read on public.guests;
create policy guests_read on public.guests for select to authenticated
  using (user_id = auth.uid() or public.is_owner(event_id));
drop policy if exists guests_insert on public.guests;
create policy guests_insert on public.guests for insert to authenticated
  with check (
    public.is_owner(event_id)
    or (user_id = auth.uid() and via = 'link' and public.is_link_event(event_id))
  );
drop policy if exists guests_update on public.guests;
create policy guests_update on public.guests for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists guests_delete on public.guests;
create policy guests_delete on public.guests for delete to authenticated
  using (public.is_owner(event_id));
-- a guest may change only their own reply
revoke update on public.guests from authenticated;
grant update (status) on public.guests to authenticated;

-- requests to join: asked by the person themselves, or by a guest who brings a friend
drop policy if exists requests_read on public.requests;
create policy requests_read on public.requests for select to authenticated
  using (user_id = auth.uid() or via = auth.uid()::text or public.is_owner(event_id));
drop policy if exists requests_insert on public.requests;
create policy requests_insert on public.requests for insert to authenticated
  with check (
    (user_id = auth.uid() and via = 'link')
    or (via = auth.uid()::text and public.is_guest(event_id) and public.allows_guest_invites(event_id))
  );
drop policy if exists requests_delete on public.requests;
create policy requests_delete on public.requests for delete to authenticated
  using (public.is_owner(event_id) or user_id = auth.uid() or via = auth.uid()::text);

-- gifts: you can read the gifts you gave; the host reads every gift on their events.
-- Everyone else sees the gift feed (names and items, no amounts) through event_gifts().
drop policy if exists gifts_read on public.gifts;
create policy gifts_read on public.gifts for select to authenticated
  using (user_id = auth.uid() or public.is_owner(event_id));
drop policy if exists gifts_insert on public.gifts;
create policy gifts_insert on public.gifts for insert to authenticated
  with check (user_id = auth.uid() and public.can_view_event(event_id) and not public.is_ticket_event(event_id));

-- tickets: you can read your own tickets; the host reads every ticket on their events.
-- There are no insert/update/delete policies: buy_ticket() and cancel_ticket() do the writing.
drop policy if exists tickets_read on public.tickets;
create policy tickets_read on public.tickets for select to authenticated
  using (user_id = auth.uid() or public.is_owner(event_id));
revoke all on public.tickets from anon, authenticated;
grant select on public.tickets to authenticated;

-- A ticketed event cannot change kind, and cannot be cut below the tickets already sold.
create or replace function public.events_ticket_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare sold integer;
begin
  if new.kind is distinct from old.kind then
    raise exception 'kind_locked';
  end if;
  if new.kind = 'ticket' then
    select count(*) into sold from public.tickets t where t.event_id = old.id and t.status = 'valid';
    if new.ticket_total < sold then
      raise exception 'total_below_sold';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists events_ticket_guard_trg on public.events;
create trigger events_ticket_guard_trg before update on public.events
  for each row execute function public.events_ticket_guard();

-- friends: a private list, visible only to its owner
drop policy if exists friends_all on public.friends;
create policy friends_all on public.friends for all to authenticated
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Functions the app calls
-- ---------------------------------------------------------------------------

-- Open an event by its code, when you are allowed to see it.
create or replace function public.get_event(p_code text)
returns setof public.events language sql stable security definer set search_path = public as $$
  select e.* from public.events e
  where e.id = lower(p_code)
    and (e.owner = auth.uid()
         or e.access = 'link'
         or exists (select 1 from public.guests g where g.event_id = e.id and g.user_id = auth.uid()));
$$;

-- Who hosts a private event, so the app can show "ask to join".
create or replace function public.event_stub(p_code text)
returns table (o_id text, o_owner uuid, o_name text)
language sql stable security definer set search_path = public as $$
  select e.id, e.owner, p.name
  from public.events e join public.profiles p on p.id = e.owner
  where e.id = lower(p_code) and auth.uid() is not null;
$$;

-- The gift feed for an event. Amounts are included only for the host.
-- o_rank is each giver's place by total given (1 = top giver), without amounts.
create or replace function public.event_gifts(p_event text)
returns table (o_gid uuid, o_user uuid, o_item text, o_emoji text, o_label text,
               o_at timestamptz, o_rank integer, o_price numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.can_view_event(p_event) then
    return;
  end if;
  return query
    with t as (
      select g.user_id as u, sum(g.price) as s
      from public.gifts g where g.event_id = p_event group by g.user_id
    ),
    r as (
      select t.u, (rank() over (order by t.s desc))::integer as rk from t
    )
    select g.id, g.user_id, g.item_id, g.emoji, g.label, g.created_at, r.rk,
           case when public.is_owner(p_event) then g.price else null end
    from public.gifts g join r on r.u = g.user_id
    where g.event_id = p_event
    order by g.created_at;
end $$;

-- How many tickets are sold, for anyone who can open the event. No buyer names.
create or replace function public.ticket_stats(p_event text)
returns table (o_sold integer, o_total integer)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.can_view_event(p_event) then
    return;
  end if;
  return query
    select (select count(*)::integer from public.tickets t where t.event_id = e.id and t.status = 'valid'),
           e.ticket_total
    from public.events e where e.id = p_event and e.kind = 'ticket';
end $$;

-- Buy tickets. Placeholder payment: records the tickets without charging anyone.
-- When real payments are added, call this only after the payment succeeds (from an Edge Function).
-- The event row is locked, so two people can never buy the last ticket at the same time.
create or replace function public.buy_ticket(p_event text, p_qty integer)
returns integer language plpgsql security definer set search_path = public as $$
declare e public.events; sold integer; i integer;
begin
  if auth.uid() is null then raise exception 'not_signed_in'; end if;
  if p_qty is null or p_qty < 1 or p_qty > 50 then raise exception 'bad_qty'; end if;
  select * into e from public.events where id = p_event and kind = 'ticket' for update;
  if not found then raise exception 'no_event'; end if;
  if e.event_date < current_date - 1 then raise exception 'sales_closed'; end if;
  if not public.can_view_event(p_event) then raise exception 'no_access'; end if;
  select count(*) into sold from public.tickets t where t.event_id = e.id and t.status = 'valid';
  if sold + p_qty > e.ticket_total then raise exception 'sold_out'; end if;
  for i in 1..p_qty loop
    insert into public.tickets (event_id, user_id, code, price)
    values (e.id, auth.uid(), upper(substr(md5(gen_random_uuid()::text), 1, 8)), e.ticket_price);
  end loop;
  if e.owner <> auth.uid() then
    insert into public.guests (event_id, user_id, via, status)
    values (e.id, auth.uid(), 'link', 'going')
    on conflict (event_id, user_id) do update set status = 'going';
  end if;
  return p_qty;
end $$;

-- The host cancels a ticket. The spot goes back on sale.
create or replace function public.cancel_ticket(p_ticket uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.tickets t set status = 'cancelled'
  where t.id = p_ticket and t.status = 'valid' and public.is_owner(t.event_id);
  if not found then raise exception 'no_ticket'; end if;
end $$;

revoke all on function public.ticket_stats(text) from public, anon;
revoke all on function public.buy_ticket(text, integer) from public, anon;
revoke all on function public.cancel_ticket(uuid) from public, anon;
grant execute on function public.ticket_stats(text) to authenticated;
grant execute on function public.buy_ticket(text, integer) to authenticated;
grant execute on function public.cancel_ticket(uuid) to authenticated;

revoke all on function public.get_event(text) from public, anon;
revoke all on function public.event_stub(text) from public, anon;
revoke all on function public.event_gifts(text) from public, anon;
grant execute on function public.get_event(text) to authenticated;
grant execute on function public.event_stub(text) to authenticated;
grant execute on function public.event_gifts(text) to authenticated;

-- ---------------------------------------------------------------------------
-- Live updates
-- ---------------------------------------------------------------------------

do $$
declare t text;
begin
  foreach t in array array['events','guests','requests','gifts','tickets'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;
