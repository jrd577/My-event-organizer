// Paste your own values from Supabase: Project Settings > API.
// The anon key is meant to be public. Your data is protected by the rules in supabase/schema.sql.
window.APP_CONFIG = {
  SUPABASE_URL: 'YOUR_SUPABASE_URL',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_KEY'
};
